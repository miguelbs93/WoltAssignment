// MARK: - EndOfSectionDTO

public struct EndOfSectionDTO: Decodable, Sendable {
    public let link: LinkDTO
    public let type: String
}

